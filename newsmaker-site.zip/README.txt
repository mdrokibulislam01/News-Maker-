NewsMaker Studio — ফ্রিতে চালানোর নিয়ম (Vercel ফ্রি প্ল্যান)
1. vercel.com এ ফ্রি অ্যাকাউন্ট খুলুন (GitHub/Google দিয়ে)।
2. এই ফোল্ডার (index.html + api/) GitHub-এ আপলোড করে "Import Project" দিন, অথবা কম্পিউটারে: npx vercel
3. ডিপ্লয় শেষে পাওয়া লিংকই আপনার ওয়েবসাইট। কোনো API কী লাগে না।
স্থানীয়ভাবে চালাতে: npx vercel dev
