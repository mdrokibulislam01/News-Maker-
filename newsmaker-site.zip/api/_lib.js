import dns from 'node:dns/promises';
import net from 'node:net';
const UA = 'NewsMakerBot/1.0 (+personal news card tool)';
export function isPrivateIp(ip){
  if(net.isIPv6(ip)){const l=ip.toLowerCase();return l==='::1'||l.startsWith('fc')||l.startsWith('fd')||l.startsWith('fe80')||l.startsWith('::ffff:')}
  const [a,b]=ip.split('.').map(Number);
  return a===10||a===127||a===0||(a===172&&b>=16&&b<=31)||(a===192&&b===168)||(a===169&&b===254)||a>=224;
}
export async function safeUrl(raw){
  let u; try{u=new URL(raw)}catch{throw new Error('লিংকটি সঠিক নয়')}
  if(!['http:','https:'].includes(u.protocol)) throw new Error('শুধু http/https লিংক চলবে');
  const addrs = await dns.lookup(u.hostname,{all:true});
  if(addrs.some(a=>isPrivateIp(a.address))) throw new Error('এই লিংক অনুমোদিত নয়');
  return u;
}
// Respect robots.txt (simple: User-agent * Disallow rules)
export async function robotsAllows(u){
  try{
    const r = await fetch(u.origin+'/robots.txt',{headers:{'user-agent':UA},signal:AbortSignal.timeout(4000)});
    if(!r.ok) return true;
    const lines=(await r.text()).split('\n').map(l=>l.split('#')[0].trim());
    let applies=false, ok=true;
    for(const l of lines){
      const m=l.match(/^([a-z-]+)\s*:\s*(.*)$/i); if(!m) continue;
      const k=m[1].toLowerCase(), v=m[2].trim();
      if(k==='user-agent') applies = v==='*' || /newsmaker/i.test(v);
      else if(applies && k==='disallow' && v && (u.pathname+u.search).startsWith(v)) ok=false;
      else if(applies && k==='allow' && v && (u.pathname+u.search).startsWith(v)) ok=true;
    }
    return ok;
  }catch{return true}
}
export { UA };
