import { safeUrl, robotsAllows, UA } from './_lib.js';
const meta=(h,names)=>{for(const n of names){
  const re=new RegExp(`<meta[^>]+(?:property|name)=["']${n}["'][^>]*>`,'i');const m=h.match(re);
  if(m){const c=m[0].match(/content=["']([^"']*)["']/i);if(c)return dec(c[1])}}return ''};
const dec=s=>s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&#x27;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>');
export default async function handler(req,res){
  try{
    const u=await safeUrl(req.query.url);
    if(!(await robotsAllows(u))) return res.status(403).json({error:'এই সাইট স্বয়ংক্রিয়ভাবে পড়তে দেয় না (robots.txt)'});
    const r=await fetch(u,{headers:{'user-agent':UA,'accept-language':'bn,en;q=0.8'},redirect:'follow',signal:AbortSignal.timeout(9000)});
    if(!r.ok) return res.status(502).json({error:'সাইট খোলা যায়নি ('+r.status+')'});
    const html=(await r.text()).slice(0,600000);
    const title=meta(html,['og:title','twitter:title'])||dec((html.match(/<title[^>]*>([^<]*)/i)||[])[1]||'').trim();
    let image=meta(html,['og:image','twitter:image']);
    if(image) try{image=new URL(image,u).href}catch{}
    res.setHeader('cache-control','s-maxage=300');
    res.json({title,description:meta(html,['og:description','description']),image,site:meta(html,['og:site_name'])||u.hostname});
  }catch(e){res.status(400).json({error:e.message||'ত্রুটি'})}
}
