import { safeUrl, UA } from './_lib.js';
export default async function handler(req,res){
  try{
    const u=await safeUrl(req.query.url);
    const r=await fetch(u,{headers:{'user-agent':UA},signal:AbortSignal.timeout(9000)});
    const type=r.headers.get('content-type')||'';
    if(!r.ok||!type.startsWith('image/')) return res.status(502).end('not an image');
    const buf=Buffer.from(await r.arrayBuffer());
    if(buf.length>8e6) return res.status(413).end('too large');
    res.setHeader('content-type',type);res.setHeader('cache-control','s-maxage=3600');res.end(buf);
  }catch(e){res.status(400).end(e.message)}
}
